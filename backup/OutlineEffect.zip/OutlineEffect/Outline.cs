﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Renderer))]
public class Outline : MonoBehaviour
{
	public int color;

    [HideInInspector]
    public OutlineEffect outlineEffect;
	[HideInInspector]
	public int originalLayer;
	[HideInInspector]
	public Material originalMaterial;

    void OnEnable()
    {
		if(outlineEffect == null)
			outlineEffect = Camera.main.GetComponent<OutlineEffect>();
		outlineEffect.AddOutline(this);
    }

    void OnDisable()
    {
        outlineEffect.RemoveOutline(this);
    }
}
