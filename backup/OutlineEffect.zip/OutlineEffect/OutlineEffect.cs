using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(Camera))]
public class OutlineEffect : MonoBehaviour
{
	List<Outline> outlines = new List<Outline>();

    public Camera sourceCamera;
    public Camera outlineCamera;

    public float lineThickness = 4f;
    public float lineIntensity = .5f;
    public int lineSoftness = 1;
    public float lineSpread = 1.0f;

    public Color lineColor0 = Color.red;
    public Color lineColor1 = Color.green;
    public Color lineColor2 = Color.blue;

    private Material outline1Material;
    private Material outline2Material;
    private Material outline3Material;
    private Material outlineMaterial;
    private Material copyDepthMaterial;
    private Material blurMaterial;
    private Material combineMaterial;

    private void Start()
    {
        if (sourceCamera == null)
        {
            sourceCamera = GetComponent<Camera>();

            if (sourceCamera == null)
                sourceCamera = Camera.main;
        }

        sourceCamera.depthTextureMode = DepthTextureMode.Depth;

        if (outlineCamera == null)
        {
            GameObject cameraGameObject = new GameObject("Outline Camera");
            cameraGameObject.transform.parent = sourceCamera.transform;
            outlineCamera = cameraGameObject.AddComponent<Camera>();
        }

        CreateMaterials();
        UpdateMaterials();
        UpdateOutlineCamera();
    }

    void OnDestroy()
    {
        DestroyMaterials();
    }

    private void RenderOutline(RenderTexture source, RenderTexture outlineTexture)
    {
        int rtW = source.width;
        int rtH = source.height;

        UpdateMaterials();
		UpdateOutlineCamera();

        RenderTexture depthTexture = RenderTexture.GetTemporary(rtW, rtH);

        Graphics.Blit(source, depthTexture, copyDepthMaterial);

		for (int i = 0; i < outlines.Count; i++)
        {
            if (outlines[i] != null)
            {
				outlines[i].originalMaterial = outlines[i].GetComponent<Renderer>().sharedMaterial;
				outlines[i].originalLayer = outlines[i].gameObject.layer;

				outlines[i].GetComponent<Renderer>().sharedMaterial = GetMaterialFromID(outlines[i].color);
                outlines[i].GetComponent<Renderer>().sharedMaterial.SetTexture("_DepthTex", depthTexture);
                outlines[i].gameObject.layer = LayerMask.NameToLayer("Outline");
            }
        }

        outlineCamera.targetTexture = outlineTexture;
        outlineCamera.Render();
        //outlineCamera.targetTexture = null;

        for (int i = 0; i < outlines.Count; i++)
        {
            if (outlines[i] != null)
            {
                outlines[i].GetComponent<Renderer>().sharedMaterial = outlines[i].originalMaterial;
                outlines[i].gameObject.layer = outlines[i].originalLayer;
            }
        }

        RenderTexture.ReleaseTemporary(depthTexture);
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        int rtW = source.width;
        int rtH = source.height;

        RenderTexture outlineFillTexture = RenderTexture.GetTemporary(rtW, rtH, 16);

        RenderOutline(source, outlineFillTexture);

        RenderTexture outlineTexture = RenderTexture.GetTemporary(rtW, rtH, 0);
        outlineMaterial.SetTexture("_OutlineSource", outlineFillTexture);
        Graphics.Blit(source, outlineTexture, outlineMaterial);

        RenderTexture.ReleaseTemporary(outlineFillTexture);

        if (lineSoftness > 0)
        {
            float widthOverHeight = (1.0f * rtW) / (1.0f * rtH);
            float oneOverBaseSize = 1.0f / 512.0f;

            RenderTexture lrTex1 = RenderTexture.GetTemporary(rtW / 2, rtH / 2, 0);
            Graphics.Blit(outlineTexture, lrTex1);

            for (int i = 0; i < lineSoftness; i++)
            {
                RenderTexture lrTex2 = RenderTexture.GetTemporary(rtW / 2, rtH / 2, 0);
                blurMaterial.SetVector("offsets", new Vector4(0.0f, lineSpread * oneOverBaseSize, 0.0f, 0.0f));
                Graphics.Blit(lrTex1, lrTex2, blurMaterial);
                RenderTexture.ReleaseTemporary(lrTex1);
                lrTex1 = lrTex2;

                lrTex2 = RenderTexture.GetTemporary(rtW / 2, rtH / 2, 0);
                blurMaterial.SetVector("offsets", new Vector4(lineSpread * oneOverBaseSize / widthOverHeight, 0.0f, 0.0f, 0.0f));
                Graphics.Blit(lrTex1, lrTex2, blurMaterial);
                RenderTexture.ReleaseTemporary(lrTex1);
                lrTex1 = lrTex2;
            }

            RenderTexture.ReleaseTemporary(outlineTexture);
            outlineTexture = lrTex1;
        }        

        combineMaterial.SetTexture("_CombineTex", outlineTexture);
        Graphics.Blit(source, destination, combineMaterial);

        RenderTexture.ReleaseTemporary(outlineTexture);
    }

    private void CreateMaterials()
    {
        combineMaterial = new Material(Shader.Find("Hidden/OutlineCombine"));
        blurMaterial = new Material(Shader.Find("Hidden/SeparableBlur"));
        copyDepthMaterial = new Material(Shader.Find("Hidden/DepthCopy"));
        outlineMaterial = new Material(Shader.Find("Hidden/OutlineEffect"));
        if (outline1Material == null)
            outline1Material = CreateMaterial(new Color(1, 0, 0, 0));
        if (outline2Material == null)
            outline2Material = CreateMaterial(new Color(0, 1, 0, 0));
        if (outline3Material == null)
            outline3Material = CreateMaterial(new Color(0, 0, 1, 0));
    }

    private void DestroyMaterials()
    {
        DestroyImmediate(outline1Material);
        DestroyImmediate(outline2Material);
        DestroyImmediate(outline3Material);
        DestroyImmediate(outlineMaterial);
        DestroyImmediate(copyDepthMaterial);
        DestroyImmediate(blurMaterial);
        DestroyImmediate(combineMaterial);
    }

    private void UpdateMaterials()
    {
        outlineMaterial.SetFloat("_LineThicknessX", lineThickness / 1000);
        outlineMaterial.SetFloat("_LineThicknessY", lineThickness / 1000);
        outlineMaterial.SetFloat("_LineIntensity", lineIntensity);
        outlineMaterial.SetColor("_LineColor1", lineColor0);
        outlineMaterial.SetColor("_LineColor2", lineColor1);
        outlineMaterial.SetColor("_LineColor3", lineColor2);
        combineMaterial.SetFloat("_Intensity", lineIntensity);
    }

    void UpdateOutlineCamera()
    {
        outlineCamera.CopyFrom(sourceCamera);
        outlineCamera.renderingPath = RenderingPath.Forward;
        outlineCamera.backgroundColor = new Color(0.0f, 0.0f, 0.0f, 0.0f);
        outlineCamera.clearFlags = CameraClearFlags.SolidColor;
        outlineCamera.cullingMask = LayerMask.GetMask("Outline");
        outlineCamera.rect = new Rect(0, 0, 1, 1);
		outlineCamera.enabled = true;
	}

    private Material GetMaterialFromID(int ID)
    {
        if (ID == 0)
            return outline1Material;
        else if (ID == 1)
            return outline2Material;
        else
            return outline3Material;
    }

    private Material CreateMaterial(Color emissionColor)
    {
        Material m = new Material(Shader.Find("Hidden/OutlineWriteEffect"));
        m.SetColor("_Color", emissionColor);
        m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        m.SetInt("_ZWrite", 0);
        m.DisableKeyword("_ALPHATEST_ON");
        m.EnableKeyword("_ALPHABLEND_ON");
        m.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        m.renderQueue = 3000;
        return m;
    }

    public void AddOutline(Outline outline)
    {
        if (!outlines.Contains(outline))
        {
			outlines.Add(outline);
        }
    }
    public void RemoveOutline(Outline outline)
	{
		outlines.Remove(outline);
    }

}
